<?php
require_once("../../../pages/system/seguranca.php");
require_once("../../../pages/system/config.php");
require_once("../../../pages/system/funcoes.system.php");

protegePagina("admin");

if (isset($_POST['enviandolink'])) {

    #Posts
    $tipocliente = anti_sql_injection($_POST['tipocliente']);
    $detalhes = anti_sql_injection($_POST['msg']);
    $nomeli = anti_sql_injection($_POST['nome']);
    $status = anti_sql_injection($_POST['status']);
    $inputlink = anti_sql_injection($_POST['link']);
} else {
    echo "Algo errado";
}


