<?php
header('location: /');